﻿namespace weeks_jason;

class Program
{
    static void Main(string[] args)
    {
        testClass.test();
    }
}
