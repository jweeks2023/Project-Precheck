namespace weeks_jason;

class testClass
{
	public static void test()
	{
		Console.WriteLine("I work!");
	}
}