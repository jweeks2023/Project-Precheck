﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
int[] num = new int[2];
Console.WriteLine(num[2]);
